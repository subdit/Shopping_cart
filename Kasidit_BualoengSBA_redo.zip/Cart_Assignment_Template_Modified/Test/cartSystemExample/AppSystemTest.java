package cartSystemExample;

import static org.junit.Assert.*;

import org.junit.Test;

public class AppSystemTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
